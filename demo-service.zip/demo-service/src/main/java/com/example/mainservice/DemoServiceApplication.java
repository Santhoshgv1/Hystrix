package com.example.mainservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@SpringBootApplication
@EnableHystrix
@RestController
public class DemoServiceApplication {

	@Autowired
	private RestTemplate template;
	
	public static void main(String[] args) {
		SpringApplication.run(DemoServiceApplication.class, args);
	}
	
	@LoadBalanced
	@Bean 
	public RestTemplate template()
	{
		return new RestTemplate();
	}
	

	@HystrixCommand(fallbackMethod = "handleOrders")
	@GetMapping("/orders")
	public String order()
	{
	String payment=	template.getForObject("http://localhost:8001/payment/status", String.class);
	String billing=	template.getForObject("http://localhost:8002/billing/status", String.class);
		return payment+" "+billing;
	}
	
	public String handleOrders()
	{
		return "Server Down";
	}
	
}
